package com.example.autototem.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.lwjgl.glfw.GLFW;

/**
 * Client-only Auto Totem controller.
 *
 * <p>26.x uses official Mojang mappings, so the implementation intentionally uses current
 * names such as {@code Minecraft}, {@code KeyMapping}, {@code Inventory}, and
 * {@code MultiPlayerGameMode#handleContainerInput}.</p>
 */
public final class AutoTotemClient implements ClientModInitializer {
    public static final String MOD_ID = "auto-totem";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final KeyMapping.Category KEY_CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(MOD_ID, "main")
    );

    private static final KeyMapping TOGGLE_KEY = KeyMappingHelper.registerKeyMapping(
            new KeyMapping(
                    "key.auto-totem.toggle",
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_R,
                    KEY_CATEGORY
            )
    );

    /** Minimum gap between attempted container actions. */
    private static final int ACTION_COOLDOWN_TICKS = 10;

    private AutoTotemConfig config;
    private int actionCooldown;
    private boolean attemptedForCurrentDanger;
    private LocalPlayer trackedPlayer;
    private ClientLevel trackedLevel;

    @Override
    public void onInitializeClient() {
        config = AutoTotemConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        LOGGER.info("Auto Totem initialized for Minecraft 26.2.");
    }

    private void onClientTick(Minecraft client) {
        handleToggleKey(client);

        if (actionCooldown > 0) {
            actionCooldown--;
        }

        LocalPlayer player = client.player;
        if (player == null) {
            resetTransientState();
            return;
        }

        if (trackedPlayer != player || trackedLevel != client.level) {
            trackedPlayer = player;
            trackedLevel = client.level;
            attemptedForCurrentDanger = false;
            actionCooldown = 0;
        }

        // Death/respawn and dimension changes produce distinct player/world state. Do not
        // carry an in-progress auto-equip attempt across those transitions.
        if (player.isDeadOrDying() || client.level == null) {
            resetTransientState();
            return;
        }

        if (!config.enabled) {
            attemptedForCurrentDanger = false;
            return;
        }

        ItemStack offhand = player.getOffhandItem();
        if (isTotem(offhand)) {
            // The server/client has acknowledged the desired state; allow a future danger
            // episode to trigger a fresh lookup if the totem is later consumed.
            attemptedForCurrentDanger = false;
            return;
        }

        boolean dangerous = isDangerous(player);
        if (!dangerous) {
            attemptedForCurrentDanger = false;
            return;
        }

        if (attemptedForCurrentDanger || actionCooldown > 0) {
            return;
        }

        // Inventory manipulation while a handled screen is open is deliberately skipped.
        // This prevents slot-id mismatches, cursor interference, and click races with the UI.
        if (client.gui.screen() != null) {
            return;
        }

        if (!(player.containerMenu instanceof InventoryMenu)) {
            return;
        }

        Inventory inventory = player.getInventory();
        int inventoryIndex = findTotemInventoryIndex(inventory);
        if (inventoryIndex < 0) {
            return;
        }

        int menuSlot = inventoryIndexToInventoryMenuSlot(inventoryIndex);
        if (menuSlot < 0) {
            return;
        }

        Slot sourceSlot = player.containerMenu.getSlot(menuSlot);
        if (sourceSlot == null || sourceSlot.getItem().isEmpty() || !isTotem(sourceSlot.getItem())) {
            return;
        }

        // Current 26.2 vanilla uses ContainerInput.SWAP and button 40 for the offhand.
        // This is exactly the same container action as the player's normal offhand swap key.
        if (client.gameMode == null) {
            return;
        }

        client.gameMode.handleContainerInput(
                player.containerMenu.containerId,
                menuSlot,
                40,
                ContainerInput.SWAP,
                player
        );

        actionCooldown = ACTION_COOLDOWN_TICKS;
        attemptedForCurrentDanger = true;
    }

    private void handleToggleKey(Minecraft client) {
        while (TOGGLE_KEY.consumeClick()) {
            config.enabled = !config.enabled;
            config.save();
            attemptedForCurrentDanger = false;
            actionCooldown = 0;
            showStatus(client, config.enabled);
        }
    }

    private boolean isDangerous(LocalPlayer player) {
        float effectiveHealth = player.getHealth();
        if (config.includeAbsorption) {
            effectiveHealth += player.getAbsorptionAmount();
        }
        return effectiveHealth <= config.healthThreshold;
    }

    private static int findTotemInventoryIndex(Inventory inventory) {
        // The player inventory's persistent item storage is the 0..35 range in 26.2:
        // 0..8 hotbar, 9..35 main inventory. Armor/offhand are equipment slots, not
        // candidates for an inventory search.
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inventory.getItem(i);
            if (isTotem(stack)) {
                return i;
            }
        }
        return -1;
    }

    private static int inventoryIndexToInventoryMenuSlot(int inventoryIndex) {
        if (inventoryIndex < 0 || inventoryIndex >= 36) {
            return -1;
        }
        return inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
    }

    private static boolean isTotem(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.is(Items.TOTEM_OF_UNDYING);
    }

    private void resetTransientState() {
        attemptedForCurrentDanger = false;
        actionCooldown = 0;
        trackedPlayer = null;
        trackedLevel = null;
    }

    private static void showStatus(Minecraft client, boolean enabled) {
        if (client.gui == null || client.gui.hud == null) {
            return;
        }

        client.gui.hud.setOverlayMessage(
                Component.literal("Auto Totem " + (enabled ? "enabled" : "disabled")),
                false
        );
    }

}
