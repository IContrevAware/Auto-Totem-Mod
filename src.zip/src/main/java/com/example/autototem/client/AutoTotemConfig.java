package com.example.autototem.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Small JSON-backed client configuration with conservative defaults. */
public final class AutoTotemConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("auto-totem");

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .create();

    private static final Path PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("auto-totem.json");

    public boolean enabled = true;
    public float healthThreshold = 8.0F;
    public boolean includeAbsorption = false;

    public static AutoTotemConfig load() {
        if (!Files.isRegularFile(PATH)) {
            AutoTotemConfig config = new AutoTotemConfig();
            config.save();
            return config;
        }

        try {
            String json = Files.readString(PATH, StandardCharsets.UTF_8);
            AutoTotemConfig config = GSON.fromJson(json, AutoTotemConfig.class);
            if (config == null) {
                config = new AutoTotemConfig();
            }
            config.sanitize();
            return config;
        } catch (IOException | JsonSyntaxException e) {
            LOGGER.warn("Could not read {}. Using defaults.", PATH, e);
            AutoTotemConfig config = new AutoTotemConfig();
            config.save();
            return config;
        }
    }

    public void save() {
        sanitize();
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException e) {
            LOGGER.warn("Could not save {}.", PATH, e);
        }
    }

    private void sanitize() {
        if (Float.isNaN(healthThreshold) || Float.isInfinite(healthThreshold)) {
            healthThreshold = 8.0F;
        }
        healthThreshold = Math.clamp(healthThreshold, 0.0F, 40.0F);
    }
}
